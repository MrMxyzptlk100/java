package com.gremio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HolaMundoApplicationTests {

	@Test
	void contextLoads() {
	}

}
